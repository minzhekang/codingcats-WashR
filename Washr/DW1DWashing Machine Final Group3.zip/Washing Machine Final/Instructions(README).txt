                      _ _                         _                      
         ___ ___   __| (_)_ __   __ _    ___ __ _| |_ ___               
        / __/ _ \ / _` | | '_ \ / _` |  / __/ _` | __/ __|       
       | (_| (_) | (_| | | | | | (_| | | (_| (_| | |_\__ \        
        \___\___/ \__,_|_|_| |_|\__, |  \___\__,_|\__|___/            
                                |___/                                   
     _                                       _        _   _              
  __| | ___   ___ _   _ _ __ ___   ___ _ __ | |_ __ _| |_(_) ___  _ __   
 / _` |/ _ \ / __| | | | '_ ` _ \ / _ \ '_ \| __/ _` | __| |/ _ \| '_ \  
| (_| | (_) | (__| |_| | | | | | |  __/ | | | || (_| | |_| | (_) | | | | 
 \__,_|\___/ \___|\__,_|_| |_| |_|\___|_| |_|\__\__,_|\__|_|\___/|_| |_| 
                                                                                                                
Washr by: Eremus Soh, Ngeow Chee Fong, Wilson Koh, Nigel Ng, Kang Min Zhe

(Dependencies required: pyrebase, win10toast, kivy, matplotlib, python)

1) Attach our sensor to the "Door Lock" light of the washing machine.
2) Run our "RUNME.py" file for the sensor to collect data.
3) Rpi will auto update the usage of the machine and the availability of it.
4) Install the dependencies required.
5) Run our "WashR_59.py" file to view the availability of the washing machine(Only for Block 59).
6) Click on "Block 59 usage information" to view the best timings to use the Washing Machine.

       :\     /;               _
      ;  \___/  ;             ; ;
     ,:-"'   `"-:.            / ;
_   /,---.   ,---.\   _     _; /
_:>((  |  ) (  |  ))<:_ ,-""_,"
    \`````   `````/""""",-""
     '-.._ v _..-'      )
       / ___   ____,..  \
      / /   | |   | ( \. \
ctr  / /    | |    | |  \ \
     `"     `"     `"    `"     Meow